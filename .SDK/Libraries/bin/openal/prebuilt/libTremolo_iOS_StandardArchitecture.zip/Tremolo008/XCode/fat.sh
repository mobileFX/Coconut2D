lipo -create -output libTremolo.a libTremolo-arm.a libTremolo-x86.a
